== For Translators ==

Note: this folder contains PO file, MO files and POT file. If you are looking for PO file, you can download it from here:

If you have created your own translation, or have an update of an existing one, please send it to Arefly <eflyjason@gmail.com> so that I can bundle it into the next release of Shortcode Toggle.

Thank you.