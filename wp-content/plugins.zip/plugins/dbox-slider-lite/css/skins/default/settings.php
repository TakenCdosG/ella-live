<?php
global $default_settings_default;
?>
