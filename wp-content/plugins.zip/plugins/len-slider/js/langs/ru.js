tinyMCE.addI18n("ru.lenslider",{
   title : "Шорткод для вставки LenSlider"
});