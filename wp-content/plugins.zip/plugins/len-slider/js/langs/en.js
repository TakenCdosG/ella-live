tinyMCE.addI18n("en.lenslider",{
   title : 'Insert LenSlider shortcode'
});