<script type="text/javascript">
	parent.parent.tb_remove();
</script>