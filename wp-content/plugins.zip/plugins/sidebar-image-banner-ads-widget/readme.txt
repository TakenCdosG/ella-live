﻿=== Sidebar Image Banner Ads Widget ===
Contributors: sureshhardiya 
Donate link:http://study-for-exam.blogspot.com/p/donate-page.html
Tags: image banner sidebar, sidebar image,ads in sidebar
Requires at least: 2.1
Tested up to: 3.9.1
Stable tag: ads in sidebar

This Plugins helps to add image banners on the sidebar. Allows to enter title, description, image on the sidebar and is very easy to use.

== Description ==

This Plugins helps to add image banners on the sidebar. Allows to enter title, description, image on the sidebar and is very easy to use.

This plugin intended for simplest use of image banners or small ads in the sidebar or any widget area in the WordPress theme. It adds image banners in following steps:

*   You have to drag 'n drop the widget to your required widget area,
*   Enter the image url and the link, title, description as per required. Choose your visibility settings.  
    
*   Save & Close. It will fit to the container it is located in.

== Installation ==

1.  Download the widget and upload it to your server through \`WP Admin -> Plugins -> Add New -> Upload\`
2.  After the upload is complete activate the plugin.
3.  Go to Appearance -> Widgets page, drag and drop the widget to your sidebar.
4.  Fill in the settings as required. You can enter, title, upload image, image link, enter description you want to have displayed.
== Frequently Asked Questions ==

**How to install the plugin?**

Simpley upload to the plugin folder and click on activate link. Once done you can put the widget anywhere in the widget area.

**Can I edit the codes?**

This is a simple  plugin with only few page codes. You can easily edit the codes according to your requirement. You can modify the codes as per your need according to license.

**Where can I contact in case of problem?**

You can email me at @itsmeskm99@gmail.com

**Can you set up this plugin in my website?**

Yes, You can email me at @itsmeskm99@gmail.com

== Screenshots ==
1. plugin search listing
2. plugin_dashboard_listing.png
3. sidebar widget settings
4. advance configuration of the sidebar image plugin