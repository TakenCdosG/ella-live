jQuery(document).ready(function($) {

	$(document).on('click', 'input.pcct-shortcode', function (event) {
		this.select();
	});

	$(document).on('mouseenter', '#pcct-ct-table tr', function (event) {
		$(this).find('.pcct-del-icon').css('display', 'inline');
	}).on('mouseleave', '#pcct-ct-table tr', function(){
		$(this).find('.pcct-del-icon').css('display', 'none');
	});

	$(document).on('click', '#add-ct', function (event) {
		$('#pcct-loading').show();
		$('#pcct-submit, #add-ct').attr("disabled", true);

		data = {
			action: 'pcct_add_control',
			pcct_ajax_nonce_add: pcct_vars.pcct_nonce
		};

 		$.post( ajaxurl, data, function(response) {

			$('#pcct-ct-table > tbody:last').append(response);

			$('#pcct-header-tag').after('<div style="display:none;" id="setting-error-settings_updated" class="updated settings-error"><p><strong>New Content Template Added!</strong></p></div>');
			$('#setting-error-settings_updated').slideDown();
			$('#setting-error-settings_updated').delay(800).slideUp();

			$('#pcct-empty-ct').hide();
			$('#pcct-empty-ct-submit').show();
			$('#pcct-loading').hide();
			$('#pcct-submit, #add-ct').attr("disabled", false);
		});

		return false; // make sure the normal submit behaviour is suppressed
	});

	$(document).on('click', '.pcct-del-icon', function (event) {
		var ct_id = $(this).attr('id');

		var conf = confirm("Delete the [" + ct_id + "] shortcode? This action cannot be undone!");
		if(conf == true){
			$('#pcct-loading').show();

			// no idea why but unless these are on separate lines they won't disable the buttons
			$('#pcct-submit').attr("disabled", true);
			$('#add-ct').attr("disabled", true);

			data = {
				action: 'pcct_delete_control',
				pcct_ajax_nonce_del: pcct_vars.pcct_nonce,
				contemplate_id: ct_id
			};

	 		$.post( ajaxurl, data, function(response) {

				$('#pcct-ct-row-' + response).fadeOut(500, function() {
					$(this).remove();
					var rowCount = $('#pcct-ct-table tr').delay(3000).length;
					if(rowCount==0) {
						$('#pcct-empty-ct-submit').hide();
						$('#pcct-empty-ct').show();
					}
				});

				$('#pcct-header-tag').after('<div style="display:none;" id="setting-error-settings_deleted" class="error settings-error"><p><strong>Content Template Deleted!</strong></p></div>');
				$('#setting-error-settings_deleted').slideDown();
				$('#setting-error-settings_deleted').delay(800).slideUp();
		
				$('#pcct-loading').hide();
				$('#pcct-submit, #add-ct').attr("disabled", false);
			});
		}
	});
});