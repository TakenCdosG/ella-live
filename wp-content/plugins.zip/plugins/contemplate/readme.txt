=== Contemplate ===
Contributors: dgwyer
Tags: content, template, multiple, post, page, comments, widgets, HTML, CSS, Javascript, text, reuse, duplicate
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 2.01

Create unlimited shortcodes containing any text/HTML you like (including CSS and JavaScript). Fantastic for managing duplicate content from your site! Keep common blocks of code in ONE place and add anywhere to your site.

== Description ==

Anyone with a WordPress site can benefit from this plugin! It's a great time-saver!

Easily manage common blocks of text/html to reuse again and again!

Contemplate allows you to create shortcodes that output text/html content anywhere you choose. This means you can define a block of HTML code and add it to any post, page, text widget, or post comment as a shortcode. The beauty of this is that you can add the shortcode to many areas of your site but only have to edit it ONCE should you need to make a change! :)

This makes it great for things like removing duplicate content, site announcements or notifications, general information, adverts, banners, comment signatures, or anything else you want!

So, say you have a block of HTML code that is repeated on multiple pages. What do you normally do when you need to update the HTML code? You have to manually edit EACH location the code has been placed in (ughh!). This isn't too bad for a few pages (but still is tedious), but what if you have to edit 10, 20, 50+ pages? With Contemplate you just have to edit the code once, and that's it!

In case you are wondering, the plugin name is derived from: [Con]tent + [Template] = Contemplate

Please rate Contemplate it if you find it useful, thanks.

See our <a href="http://www.presscoders.com" target="_blank">WordPress development site</a> for more themes and Plugins.

== Installation ==

http://codex.wordpress.org/Managing_Plugins#Automatic_Plugin_Installation

== Screenshots ==

1. Create unlimite content templates on the Plugin settings page.
2. Add the resulting shortcodes to one or more pages (or posts, text widgets, or post comments).
3. The content templates render exactly as if you entered the content directly into the page editor!

== Changelog ==

*2.01 update*

* Fixed error in the description.

*2.0 update*

* Complete Plugin rewrite.
* No longer dependent on Silverlight.
* Unlimited content templates.

*1.05 update*

* Now fully compatible with WordPress 3.0!

*1.01 update*

* Minor update to WordPress plugin page.

*1.0 update*

* First release of Contemplate!