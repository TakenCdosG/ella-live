=== Kirki ===
Contributors: aristath, fovoc
Donate link: http://kirki.org
Tags: customizer
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tired of all the bloated options frameworks? You can use the WordPress Customizer instead, and extend it using Kirki!

== Description ==

For documentation and examples please visit [kirki.org](http://kirki.org).

== Installation ==

Just install this plugin and activate it.
For configuration instructions please visit http://kirki.org/#configuration

== Changelog ==

= 0.4 =
* Fix: bugfix for selector
* New: Change the Kirki theme based on which admin theme is selected.
* Fix: Tranlsation domain issue
* New: Added a "group_title" control
* Fix: Updated the required script
* Fix: Updating CSS
* Other minor improvements and bugfixes

= 0.3 =
* new: added background field
* new: added 'output' argument to directly output the CSS

= 0.2 =
* Initial version
