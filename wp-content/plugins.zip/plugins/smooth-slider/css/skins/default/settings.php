<?php
global $default_settings_default;
$default_settings_default = array(
	'bg_color'=>'#ffffff', 
	'height'=>'250',
	'width'=>'450',
	'border'=>'0',
	'brcolor'=>'#dddddd',
	'prev_next'=>'0',
	'ptitle_font'=>'Trebuchet MS',
	'ptitle_fsize'=>'14',
	'ptitle_fstyle'=>'bold',
	'ptitle_fcolor'=>'#000000',
	'img_align'=>'left',
	'img_height'=>'120',
	'img_width'=>'165',
	'img_border'=>'1',
	'img_brcolor'=>'#000000',
	'content_font'=>'Verdana',
	'content_fsize'=>'12',
	'content_fstyle'=>'normal',
	'content_fcolor'=>'#333333',
	'content_from'=>'content',
	'content_chars'=>'300'
);
?>
